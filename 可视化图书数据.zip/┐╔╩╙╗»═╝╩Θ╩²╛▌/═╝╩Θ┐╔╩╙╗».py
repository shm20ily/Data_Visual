import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 中文乱码的处理
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
# 读取数据
df = pd.read_csv('train_dataset.csv')
# 统计图书数量最多的top20用户
top_user = df.groupby(df['user_id']).count()['item_id'].sort_values(ascending=False)[:20]
x_user = top_user.index.tolist()    # top20用户
y_item = top_user.values    # 图书数量最多
li_user = []
users = pd.Series(data=x_user, index=y_item)    # 新建Series按图书数量不同分类用户
for item in set(y_item):
    li_user.append(users[item].values)

# 统计最多用户拥有的top20本图书
top_item = df.groupby(df['item_id']).count()['user_id'].sort_values(ascending=False)[:20]
x_item = top_item.index.tolist()    # top20图书
y_user = top_item.values    # 用户数量

# 设置图框的大小
fig = plt.figure(figsize=(10, 6))
# 直方图
nums, bins, patches = plt.hist(y_item,  # 绘图数据
                               bins=6,  # 指定直方图的条形数
                               color='steelblue',  # 指定填充色
                               edgecolor='k')   # 指定直方图的边界色
plt.title('top20用户的图书数量分布')
plt.xlabel('图书数量')
plt.ylabel('top20用户')
# 在不同的图书数量上显示用户ID
for num, bin, user in zip(nums, bins, li_user):
    plt.annotate(user, xy=(bin, num), xytext=(bin+0.7, num+0.2))
# 显示图形
plt.show()

bar_width = 0.35    # 初始化条形大小
# 绘图
plt.bar(np.arange(20), y_user, color='steelblue', alpha=0.8, width=bar_width)
# 添加轴标签
plt.xlabel('Top20图书')
plt.ylabel('用户数量')
# 添加标题
plt.title('最多用户拥有的top20本书分布')
# 添加刻度标签
plt.xticks(np.arange(20) + bar_width, x_item)
# 设置Y轴的刻度范围
plt.ylim([13000, 23000])
# 显示图例
plt.legend()
# # 显示图形
plt.show()
