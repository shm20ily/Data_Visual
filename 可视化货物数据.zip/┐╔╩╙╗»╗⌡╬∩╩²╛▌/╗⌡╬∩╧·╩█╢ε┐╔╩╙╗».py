import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 设置中文编码和负号的正常显示
plt.rcParams['font.sans-serif'] = 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False

n = np.array([[1, 'car', 100, 1000000], [2, 'phone', 150, 5000]])
df = pd.DataFrame(n, columns=['Day', 'Name', 'Num', 'Price'])
print('货物种类：', df['Name'].values)
print('销售数量：', df['Num'].values)
# n1 = list(n[:, 0:1].flatten())  # day
# n1 = list(map(int, n1))
#
# n2 = n[:, 1:2].flatten()  # name
# print(n2)
#
# n3 = list(n[:, -1:].flatten())  # price
# n3 = list(map(int, n3))
# print(n3)

# plt.figure(figsize=(8, 6))  # 定义图的大小
# plt.xlabel("time(day)")  # X轴标签
# plt.xticks(n1)
# plt.ylabel("Price")  # Y轴坐标标签
# plt.title("每天的销售额")  # 曲线图的标题
# plt.plot(n1, [100, 150])  # 绘制曲线图
# plt.show()

# 将横、纵坐标轴标准化处理，保证饼图是一个正圆，否则为椭圆
plt.axes(aspect='equal')
# 绘制饼图
plt.pie(x=df['Num'].values,  # 绘图数据
        labels=df['Name'].values,  # 添加标签
        autopct='%.1f%%',  # 设置百分比的格式，这里保留一位小数
        pctdistance=0.8,  # 设置百分比标签与圆心的距离
        labeldistance=1.15,  # 设置标签与圆心的距离
        startangle=180,  # 设置饼图的初始角度
        radius=1.5,  # 设置饼图的半径
        counterclock=False,  # 是否逆时针，这里设置为顺时针方向
        wedgeprops={'linewidth': 1.5, 'edgecolor': 'green'},  # 设置饼图内外边界的属性值
        textprops={'fontsize': 12, 'color': 'k'},  # 设置文本标签的属性值
        center=(1.8, 1.8),)  # 设置饼图的原点
# 添加图标题
plt.title('每种货物的销售数量')
plt.tight_layout()
plt.show()
